
class Config{

}

class DevelopmentConfig extends Config{
    public adminUrl = "http://localhost:8080/api/admin/";
    public companyUrl = "http://localhost:8080/api/company/";
    public customerUrl = "http://localhost:8080/api/customer/";
    public couponsUrl = "http://localhost:8080/allCoupons/";
    public authUrl = "http://localhost:8080/auth/"
}

class ProductionCofig extends Config{
    public adminUrl = "/api/admin/";
    public companyUrl = "/api/company/";
    public customerUrl = "/api/customer/";
    public couponsUrl = "/allCoupons/";
    public authUrl = "/auth/";
}

const appConfig = process.env.NODE_ENV === "development"
? new DevelopmentConfig()
: new ProductionCofig();

export default appConfig;