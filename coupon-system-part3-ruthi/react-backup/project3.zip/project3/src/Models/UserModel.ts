class UserModel{
    constructor (
        public token: string,
        public email: string,
        public clientType: string,
    ){}
}
export default UserModel;

