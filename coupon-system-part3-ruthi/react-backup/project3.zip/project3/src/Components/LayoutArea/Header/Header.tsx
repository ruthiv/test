import { Link, NavLink, Outlet } from "react-router-dom";
import AuthMenu from "../../AuthArea/AuthMenu/AuthMenu";
import Routing from "../Routing/Routing";
import "./Header.css";
import logo from "../../../Assets/Images/logo1.png";



function Header(): JSX.Element {
    return (
        <div className="Header">
             <img  className="specialLogo" src={logo} alt="logo" /> 
            <Link to={"/home"}><h1>Coupon System Ruthi</h1></Link>
            {/* <Routing />
            <Outlet /> */}
			<AuthMenu/>
        </div>
    );
}

export default Header;
