import { useNavigate, useParams } from "react-router-dom";
import "./UpdateCompany.css";
import * as yup from 'yup';
import { yupResolver } from "@hookform/resolvers/yup";
import adminService from "../../../Services/AdminService";
import notify from "../../../Services/NotificationService";
import CompanyModel from "../../../Models/CompanyModel";
import { useForm, useFormState } from "react-hook-form";
import { useEffect, useState } from "react";
import store from "../../../Redux/Store";
import { updateCompanyAction } from "../../../Redux/CompanyState";

function UpdateCompany(): JSX.Element {
    const navigate = useNavigate();
    const params = useParams();
    const companyId: number = Number(params.id);
    const [company, setCompany] = useState<CompanyModel>(store.getState().companyReducer.companies.filter(company => company.id === companyId)[0]);

    const schema = yup.object().shape({
        name: yup.string().required("Name is required"),
        email: yup.string().required("Email is required"),
        password: yup.string().min(4, "password is minumum 4 characters").required("Password is required")
    })


    let defaultValueObj = {...company}

    const { register, handleSubmit, control, formState: { errors, isDirty, isValid } } = useForm<CompanyModel>({
        defaultValues: defaultValueObj,
        mode: "all",
        resolver: yupResolver(schema),
    })
    
    const sendUpdateCompany = (company : CompanyModel): void => {
        adminService.updateCompany(company).then((res) => {
            notify.success("Updated company successfully");
            store.dispatch(updateCompanyAction(company))
            navigate("/admin/companies");
        }).catch((error) => {
            notify.error(error);
        })
    }

    return (
        <div>
			<h1>Update Company</h1>
            <form className='UpdateCompany' onSubmit={handleSubmit(sendUpdateCompany)}>
                <label htmlFor="name">Name</label>
                <input {...register("name")} id='name' type="text"  />
                <span>{errors.name?.message}</span>

                <label htmlFor="email">Email</label>
                <input {...register("email")} id='email' type="email" />
                <span>{errors.email?.message}</span>

                <label htmlFor="password">Password</label>
                <input {...register("password")} id='password' type="password"  />
                <span>{errors.password?.message}</span>
                
                <div className='vertical-center'>
                <button disabled={!isValid}>Update</button>
                </div>
            </form>
        </div>
    );
}

export default UpdateCompany;
