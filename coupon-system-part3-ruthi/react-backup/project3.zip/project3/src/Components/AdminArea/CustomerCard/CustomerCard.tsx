import { NavLink, useNavigate } from "react-router-dom";
import CustomerModel from "../../../Models/CustomerModel";
import "./CustomerCard.css";


interface CustomerCardProps{
    customer: CustomerModel;
}

function CustomerCard(props: CustomerCardProps): JSX.Element {
    const navigate = useNavigate();

    function customerDetail() {
        navigate("/admin/customers/details/" + props.customer.id)
    }
    return (
        <div className="CustomerCard">
			<p>Name: {props.customer.firstName} {props.customer.lastName}</p>
            {/* <p>Email: {props.customer.email}</p>
            <p>Password: {props.customer.password}</p> */}
            <button className="ButtonCustomer" onClick={customerDetail}>show more</button>
        </div>
    );
}

export default CustomerCard;
