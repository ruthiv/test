import { useNavigate, useParams } from "react-router-dom";
import "./UpdateCustomer.css";
import * as yup from 'yup';
import { useForm } from "react-hook-form";
import CustomerModel from "../../../Models/CustomerModel";
import { useState } from "react";
import store from "../../../Redux/Store";
import adminService from "../../../Services/AdminService";
import { updateCustomerAction } from "../../../Redux/CustomerState";
import notify from "../../../Services/NotificationService";
import { yupResolver } from "@hookform/resolvers/yup";

function UpdateCustomer(): JSX.Element {
    const navigate = useNavigate();
    const params = useParams();
    const customerId: number = Number(params.id);
    const [customer, setCustomer] = useState<CustomerModel>(store.getState().customerReducer.customers.filter(c => c.id === customerId)[0]);

   
    const schema = yup.object().shape({
        firstName: yup.string().required("First Name is required"),
        lastName: yup.string().required("Last Name is required"),
        email: yup.string().required("Email is required"),
        password: yup.string().min(4, "password is minimum 4 characters").required("Password is required")
    })

    let defaultValueObj = {...customer}

    const { register, handleSubmit, control, formState: { errors, isDirty, isValid } } = useForm<CustomerModel>({
        defaultValues: defaultValueObj,
        mode: "all",
        resolver: yupResolver(schema),
    })

    const sendUpdateCustomer = (customer : CustomerModel): void => {
        adminService.updateCustomer(customer).then((res) => {
            notify.success("Updated customer successfully");
            store.dispatch(updateCustomerAction(customer))
            navigate("/admin/customers");
            
        }).catch((error) => {
            notify.error(error);
        })
    }
    

    return (
        <div>
			<h1>Update Customer</h1>
            <form className='UpdateCustomer' onSubmit={handleSubmit(sendUpdateCustomer)}>
            <label htmlFor="firstName">Name</label>
                <input {...register("firstName")} id='firstName' type="text"/>
                <span>{errors.firstName?.message}</span>
                
                <label htmlFor="lastName">Name</label>
                <input {...register("lastName")} id='lastName' type="text"/>
                <span>{errors.lastName?.message}</span>

                <label htmlFor="email">Email</label>
                <input {...register("email")} id='email' type="email"/>
                <span>{errors.email?.message}</span>

                <label htmlFor="password">Password</label>
                <input {...register("password")} id='password' type="password"/>
                <span>{errors.password?.message}</span>

                <div className='vertical-center'>
                <button disabled={!isValid}>Update</button>
                </div>
               
            </form>
        </div>
    );
}

export default UpdateCustomer;
