import { useNavigate } from "react-router-dom";
import "./AddCompany.css";
import * as yup from 'yup';
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm } from "react-hook-form";
import CompanyModel from "../../../Models/CompanyModel";
import adminService from "../../../Services/AdminService";
import notify from "../../../Services/NotificationService";
import store from "../../../Redux/Store";
import { addCompanyAction } from "../../../Redux/CompanyState";

function AddCompany(): JSX.Element {
    const navigate = useNavigate();
    
    const schema = yup.object().shape({
        name: yup.string().required("Name is required"),
        email: yup.string().required("Email is required"),
        password: yup.string().min(4, "password is minumum 4 characters").required("Password is required")
    })
    
    const { register, handleSubmit, formState: { errors, isDirty, isValid } } = useForm<CompanyModel>({
        mode: "all",
        resolver: yupResolver(schema),
    })
    const sendCompany = (company: CompanyModel): void => {
        adminService.addCompany(company).then((res) => {
            store.dispatch(addCompanyAction(company));
            notify.success("Added company successfully");
            navigate("/admin/companies");

        }).catch((error) => {
            notify.error(error);
        })
    }


    return (
        <div>
            <h1>Add Company</h1>
            <form className='addCompany' onSubmit={handleSubmit(sendCompany)}>
                <label htmlFor="name">Name</label>
                <input {...register("name")} id='name' type="text" placeholder='name company here' />
                <span>{errors.name?.message}</span>

                <label htmlFor="email">Email</label>
                <input {...register("email")} id='email' type="email" placeholder='email here' />
                <span>{errors.email?.message}</span>

                <label htmlFor="password">Password</label>
                <input {...register("password")} id='password' type="password" placeholder='password here' />
                <span>{errors.password?.message}</span>
                
                <div className='vertical-center'>
                <button disabled={!isValid}>Add</button>
                </div>
                
            </form>

        </div>
    );
}

export default AddCompany;









