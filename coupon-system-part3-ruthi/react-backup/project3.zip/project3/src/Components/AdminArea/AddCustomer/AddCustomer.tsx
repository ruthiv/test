import { useNavigate } from "react-router-dom";
import "./AddCustomer.css";
import * as yup from 'yup';
import { yupResolver } from "@hookform/resolvers/yup";
import CustomerModel from "../../../Models/CustomerModel";
import { useForm } from "react-hook-form";
import notify from "../../../Services/NotificationService";
import adminService from "../../../Services/AdminService";
import store from "../../../Redux/Store";
import { addCustomerAction } from "../../../Redux/CustomerState";

function AddCustomer(): JSX.Element {
    const navigate = useNavigate();

    const schema = yup.object().shape({
        firstName: yup.string().required("First Name is required"),
        lastName: yup.string().required("Last Name is required"),
        email: yup.string().required("Email is required"),
        password: yup.string().min(4, "password is minumum 4 characters").required("Password is required")
    })

    const { register, handleSubmit, formState: { errors, isDirty, isValid } } = useForm<CustomerModel>({
        mode: "all",
        resolver: yupResolver(schema),
    })
    const sendCustomer = (customer: CustomerModel): void => {
        adminService.addCustomer(customer).then((res) => {
            store.dispatch(addCustomerAction(customer))
            notify.success("Added customer successfully");
            navigate("/admin/customers");

        }).catch((error) => {
            notify.error(error);
        })
    }

    return (
        <div>
            <h1>Add Customer</h1>
            <form className="AddCustomer" onSubmit={handleSubmit(sendCustomer)}>
                <label htmlFor="firstName">First Name</label>
                <input {...register("firstName")} id='firstName' type="text" placeholder='firstName customer here' />
                <span>{errors.firstName?.message}</span>

                <label htmlFor="lastName">Last Name</label>
                <input {...register("lastName")} id='lastName' type="text" placeholder='LastName customer here' />
                <span>{errors.lastName?.message}</span>

                <label htmlFor="email">Email</label>
                <input {...register("email")} id='email' type="email" placeholder='email here' />
                <span>{errors.email?.message}</span>

                <label htmlFor="password">Password</label>
                <input {...register("password")} id='password' type="password" placeholder='password here' />
                <span>{errors.password?.message}</span>

                <div className='vertical-center'>
                <button disabled={!isValid}>Add</button>
                </div>
                
            </form>
        </div>
    );
}

export default AddCustomer;
