import { yupResolver } from "@hookform/resolvers/yup";
import { useForm } from "react-hook-form";
import { useNavigate, useParams } from "react-router-dom";
import CouponModel from "../../../Models/CouponModel";
import "./PurchaseCoupon.css";
import * as yup from 'yup';
import customerService from "../../../Services/CustomerService";
import store from "../../../Redux/Store";
import notify from "../../../Services/NotificationService";
import { addMyCouponAction } from "../../../Redux/CustomerState";
import { useState } from "react";

function PurchaseCoupon(): JSX.Element {
    const navigate = useNavigate();
    const params = useParams();
    const couponId: number = Number(params.id);
    const [coupon, setCoupon] = useState<CouponModel>(store.getState().companyReducer.coupons.filter(coupon => coupon.id === couponId)[0]);

    // function getDateWithOutTime (): Date {
    //     let curDate = new Date();
    //     curDate.setHours(0, 0, 0, 0);
    //     return curDate;
    // }

    const schema = yup.object().shape({
        category: yup.string().required("Category is required"),
        title: yup.string().required("Title is required"),
        description: yup.string().required("Description is required"),
        startDate: yup.date().required("StartDate is required"),
        endDate: yup.date().required("EndDate is required"),
        amount: yup.number().required("Password is required"),
        price: yup.number().required("Price is required"),
        image: yup.string().required("Image is required")
    })
    let defaultValueObj = {...coupon}

    const { register, handleSubmit, control, formState: { errors, isDirty, isValid } } = useForm<CouponModel>({
        defaultValues: defaultValueObj,
        mode: "all",
        resolver: yupResolver(schema),
    })
    
  
     const sendCoupon = (coupon: CouponModel): void => {
        customerService.purchaseCoupon(coupon).then((res) => {
            store.dispatch(addMyCouponAction(res.data));
            notify.success("purchase coupon successfully");
            navigate("/customer/my-coupons");
        }).catch((error) => {
            notify.error(error);
        })
    }

    return (
        <div>
			<h1>Purchase Coupon</h1>
            <form className='PurchaseCoupon' onSubmit={handleSubmit(sendCoupon)}>
            
            <select {...register("category")} disabled name="category" id="category">
                    <option value="FOOD">Food</option>
                    <option value="ELECTRICITY">Electricity</option>
                    <option value="RESTAURANT">Restaurant</option>
                    <option value="VACATION">Vacation</option>
                </select>
                <span>{errors.category?.message}</span>

                <label htmlFor="title">Title</label>
                <input {...register("title")} disabled id='title' type="text" placeholder='title company here' />
                <span>{errors.title?.message}</span>

                <label htmlFor="description">Description</label>
                <input {...register("description")}disabled id='description' type="text" placeholder='Description here' />
                <span>{errors.description?.message}</span>

                <label htmlFor="startDate">Start Date</label>
                <input {...register("startDate")} disabled id='startDate' type="date" placeholder='Start Date here' />
                <span>{errors.startDate?.message}</span>

                <label htmlFor="endDate">End Date</label>
                <input {...register("endDate")}disabled id='endDate' type="date" placeholder='End Date here' />
                <span>{errors.endDate?.message}</span>

                <label htmlFor="amount">Amount</label>
                <input {...register("amount")} disabled id='amount' type="number" placeholder='amount here' />
                <span>{errors.amount?.message}</span>

                <label htmlFor="price">Price</label>
                <input {...register("price")} disabled id='price' type="number" placeholder='price here' />
                <span>{errors.price?.message}</span>

                <label htmlFor="image">Image</label>
                <img src={coupon?.image} alt="image" />
                {/* <input {...register("image")} id='image' type="text" placeholder='image here' /> */}
                <span>{errors.image?.message}</span>

                <button>purchase</button>
            </form>
        </div>
    );
}
export default PurchaseCoupon;
