import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import CouponModel from "../../../Models/CouponModel";
import { fetchMyCouponAction } from "../../../Redux/CustomerState";
import store from "../../../Redux/Store";
import customerService from "../../../Services/CustomerService";
import notify from "../../../Services/NotificationService";
import CouponCard from "../CouponCardForCustomer/CouponCardForCustomer";
import "./MyCouponList.css";

function CouponList(): JSX.Element {
    const [coupons, setCoupons] = useState<CouponModel[]>([]);

    const navigate = useNavigate();

    
    useEffect(() => {
        customerService.getCustomerCoupons().then((res) => {
            // notify.success("Fetched Coupons Seccussfully")
            setCoupons(res.data);
            store.dispatch(fetchMyCouponAction(res.data));
        }).catch((error) => {
            notify.error(error);
        })
    }, []);

   
    return (
        <div className="CouponList">
            {coupons.length > 0 ? coupons.map((coupon) => (
                <CouponCard key={coupon.id} coupon={coupon} />
            )) : <span>no coupons yet</span>}
        </div>
    );
}

export default CouponList;
