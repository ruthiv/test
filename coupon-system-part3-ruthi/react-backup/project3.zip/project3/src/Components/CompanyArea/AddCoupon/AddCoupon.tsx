import { useNavigate } from "react-router-dom";
import "./AddCoupon.css";
import * as yup from 'yup';
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm } from "react-hook-form";
import CouponModel from "../../../Models/CouponModel";
import companyService from "../../../Services/CompanyService";
import store from "../../../Redux/Store";
import notify from "../../../Services/NotificationService";
import { addCouponAction } from "../../../Redux/CompanyState";
import moment from "moment";

function AddCoupon(): JSX.Element {
    const navigate = useNavigate();

    function getDateWithOutTime (): Date {
        let curDate = new Date();
        curDate.setHours(0, 0, 0, 0);
        return curDate;
    }
    

    const schema = yup.object().shape({
        category: yup.string().required("Category is required"),
        title: yup.string().required("Title is required"),
        description: yup.string().required("Description is required"),
        startDate: yup.date().min(getDateWithOutTime(), "coupon should start from today").required("StartDate is required"),
        endDate: yup.date().min(yup.ref("startDate")).required("EndDate is required"),
        amount: yup.number().min(1).required("Password is required"),
        price: yup.number().min(0).required("Price is required"),
        image: yup.string().required("Image is required")
    })

    const { register, handleSubmit, formState: { errors, isDirty, isValid } } = useForm<CouponModel>({
        mode: "all",
        resolver: yupResolver(schema),
    })

    const sendCoupon = (coupon: CouponModel): void => {
        companyService.addCoupon(coupon).then((res) => {
            store.dispatch(addCouponAction(coupon));
            notify.success("Added coupon successfully");
            navigate("/company/coupons");
        }).catch((error) => {
            notify.error(error);
        })
    }

    return (
        <div>
            <h1>Add Coupon</h1>
            <form className='AddCoupon' onSubmit={handleSubmit(sendCoupon)}>
                <select {...register("category")} name="category" id="category">
                    <option value="FOOD">Food</option>
                    <option value="ELECTRICITY">Electricity</option>
                    <option value="RESTAURANT">Restaurant</option>
                    <option value="VACATION">Vacation</option>
                </select>
                <span>{errors.category?.message}</span>

                <label htmlFor="title">Title</label>
                <input {...register("title")} id='title' type="text" placeholder='title company here' />
                <span>{errors.title?.message}</span>

                <label htmlFor="description">Description</label>
                <input {...register("description")} id='description' type="text" placeholder='Description here' />
                <span>{errors.description?.message}</span>

                <label htmlFor="startDate">Start Date</label>
                <input {...register("startDate")} id='startDate' type="date" placeholder='Start Date here' />
                <span>{errors.startDate?.message}</span>

                <label htmlFor="endDate">End Date</label>
                <input {...register("endDate")} id='endDate' type="date" placeholder='End Date here' />
                <span>{errors.endDate?.message}</span>

                <label htmlFor="amount">Amount</label>
                <input {...register("amount")} id='amount' type="number" placeholder='amount here' />
                <span>{errors.amount?.message}</span>

                <label htmlFor="price">Price</label>
                <input {...register("price")} id='price' type="number" placeholder='price here' />
                <span>{errors.price?.message}</span>

                <label htmlFor="image">Image</label>
                <input {...register("image")} id='image' type="text" placeholder='image here' />
                <span>{errors.image?.message}</span>
                <button disabled={!isValid}>Add</button>
            </form>
        </div>
    );
}

export default AddCoupon;
