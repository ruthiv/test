import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from 'yup';
import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import CouponModel from "../../../Models/CouponModel";
import store from "../../../Redux/Store";
import companyService from "../../../Services/CompanyService";
import "./UpdateCoupon.css";
import notify from "../../../Services/NotificationService";
import CouponDetails from "../CouponDetails/CouponDetails";
import { updateCouponAction } from "../../../Redux/CompanyState";
import { useForm } from "react-hook-form";

function UpdateCoupon(): JSX.Element {
    const navigate = useNavigate();
    const params = useParams();
    const couponId: number = Number(params.id);
    const [coupon, setCoupon] = useState<CouponModel>(store.getState().companyReducer.coupons.filter(coupon => coupon.id === couponId)[0]);

    const schema = yup.object().shape({
        category: yup.string().required("Category is required"),
        title: yup.string().required("Title is required"),
        description: yup.string().required("Description is required"),
        startDate: yup.date().required("StartDate is required"),
        endDate: yup.date().min(yup.ref("startDate")).required("EndDate is required"),
        amount: yup.number().min(1).required("Password is required"),
        price: yup.number().min(0).required("Price is required"),
        image: yup.string().required("Image is required")
    })

    let defaultValueObj = {...coupon}

    const { register, handleSubmit, control, formState: { errors, isDirty, isValid } } = useForm<CouponModel>({
        defaultValues: defaultValueObj,
        mode: "all",
        resolver: yupResolver(schema),
    })
    
    const sendUpdateCoupon = (coupon : CouponModel): void => {
        companyService.updateCoupon(coupon).then((res) => {
            notify.success("Updated coupon successfully");
            store.dispatch(updateCouponAction(coupon))
            navigate("/company/coupons");
        }).catch((error) => {
            notify.error(error);
        })
    }

    return (
        <div>
			<h1>Update Coupon</h1>
            <form className='UpdateCoupon' onSubmit={handleSubmit(sendUpdateCoupon)}>
            
            <select {...register("category")} name="category" id="category">
                    <option value="FOOD">Food</option>
                    <option value="ELECTRICITY">Electricity</option>
                    <option value="RESTAURANT">Restaurant</option>
                    <option value="VACATION">Vacation</option>
                </select>
                <span>{errors.category?.message}</span>

                <label htmlFor="title">Title</label>
                <input {...register("title")} id='title' type="text" />
                <span>{errors.title?.message}</span>

                <label htmlFor="description">Description</label>
                <input {...register("description")} id='description' type="text" />
                <span>{errors.description?.message}</span>

                <label htmlFor="startDate">Start Date</label>
                <input {...register("startDate")} id='startDate' type="date" />
                <span>{errors.startDate?.message}</span>

                <label htmlFor="endDate">End Date</label>
                <input {...register("endDate")} id='endDate' type="date"/>
                <span>{errors.endDate?.message}</span>

                <label htmlFor="amount">Amount</label>
                <input {...register("amount")} id='amount' type="number" />
                <span>{errors.amount?.message}</span>

                <label htmlFor="price">Price</label>
                <input {...register("price")} id='price' type="number"/>
                <span>{errors.price?.message}</span>

                <label htmlFor="image">Image</label>
                <img src={coupon.image} />
                <input type="file" {...register("imageFile")} id='imageFile' />
                <span>{errors.imageFile?.message}</span>

                <div className='vertical-center'>
                <button disabled={!isValid}>Update</button>
                </div>
            </form>
        </div>
    );
}

export default UpdateCoupon;
