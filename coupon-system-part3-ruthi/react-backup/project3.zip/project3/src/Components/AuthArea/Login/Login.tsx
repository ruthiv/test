import React from 'react'
import "./Login.css"
import * as yup from 'yup'
import { yupResolver } from "@hookform/resolvers/yup"
import { useForm } from 'react-hook-form'
import notify from "../../../Services/NotificationService"
import UserCredentialsModel from '../../../Models/UserCredentialsModel'
import loginService from '../../../Services/LoginService'
import { useNavigate } from 'react-router-dom'
import store from '../../../Redux/Store'
import { loginAction } from '../../../Redux/AuthState'

function Login() {

    const navigate = useNavigate();
    // Step 1 schema for forms
    const schema = yup.object().shape({
        email: yup.string().required("Email is required"),
        password: yup.string().min(4, "password is minumum 4 characters").required("Password is required"),
        clientType: yup.string().required("ClientType is required")
    })

    // Step 2 userForm with Yup aka valid the form and register it
    const { register, handleSubmit, formState: { errors, isDirty, isValid } } = useForm<UserCredentialsModel>({
        mode: "all",
        resolver: yupResolver(schema),
    })

    const loginFromServer = (userCredential : UserCredentialsModel): void => {
        loginService.login(userCredential).then((res) => {
            notify.success("Loggedin Successfully");
            store.dispatch(loginAction(res.data));
            navigate("/home");
            
        }).catch((error) => {
            notify.error(error);
           
        })
    }

    return (
        <div>
            <h1>Login</h1>
            <form className='login' onSubmit={handleSubmit(loginFromServer)}>
                <label htmlFor="email">Email</label>
                <input {...register("email")} id='email' type="email" placeholder='email here' />
                <span>{errors.email?.message}</span>

                <label htmlFor="password">Password</label>
                <input {...register("password")} id='password' type="password" placeholder='password here' />
                <span>{errors.password?.message}</span>

                <select {...register("clientType")} name="clientType" id="clientType">
                    <option disabled value="">Select client Type </option>
                    <option value="ADMIN">Admin</option>
                    <option value="COMPANY">Company</option>
                    <option value="CUSTOMER">Customer</option>
                </select>
                <span>{errors.clientType?.message}</span>
                <div className='vertical-center'>
                <button disabled={!isValid}>Login</button>
                </div>
               {/* <div>
               <label htmlFor="dropdownCheck">Remember me</label>
               <input type="checkbox" id="dropdownCheck"/>
               </div> */}
               </form>

        </div>
    )
}

export default Login