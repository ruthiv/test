import axios, { AxiosResponse } from "axios";
import CompanyModel from "../Models/CompanyModel";
import CustomerModel from "../Models/CustomerModel";
import UserCredentialsModel from "../Models/UserCredentialsModel";
import { AuthActionType } from "../Redux/AuthState";
import store from "../Redux/Store";
import appConfig from "../Utils/Config";


class LoginService {

    private loginUrl = appConfig.authUrl;


    public login(UserCredentials: UserCredentialsModel): Promise<AxiosResponse<string>> {
        return axios.post(this.loginUrl + "login", UserCredentials);
    }

    // public logout(): void {
    //     store.dispatch
    // }
    

        // public async login(UserCredentials: UserCredentialsModel): Promise<void> {
        //     const response = await axios.post<string>(this.loginUrl, UserCredentials);
        //     const token = response.data;
        //     console.log("token: "+token);
            
        //    store.dispatch({type:AuthActionType.Login, payload:token});
        // }
    
        public logout(){
            store.dispatch({type:AuthActionType.Logout});
        }
    
    

}

//externalize an instance of the service - like singleton
const loginService = new LoginService();
export default loginService;