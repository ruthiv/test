import { AxiosResponse } from "axios";
import CompanyModel from "../Models/CompanyModel";
import CouponModel from "../Models/CouponModel";
import appConfig from "../Utils/Config";
import tokenAxios from "./TokenService";

class CompanyService{

    private companyUrl = appConfig.companyUrl;

    public addCoupon(coupon: CouponModel): Promise<AxiosResponse<any>>{
        return tokenAxios.post(this.companyUrl, coupon);
    }

    public updateCoupon(coupon:CouponModel): Promise<AxiosResponse<any>>{
        const fd = new FormData();
        fd.append("id", coupon.id.toString());
        fd.append("category", coupon.category);
        fd.append("title", coupon.title);
        fd.append("description", coupon.description);
        fd.append("startDate", coupon.startDate.toString());
        fd.append("endDate", coupon.endDate.toString());
        fd.append("amount", coupon.amount.toString());
        fd.append(" price", coupon. price.toString());
        fd.append("imageFile", coupon.imageFile as File);

        return tokenAxios.put(this.companyUrl, fd);
    }
    public deleteCoupon(couponId:number): Promise<AxiosResponse<any>>{
        return tokenAxios.delete(this.companyUrl+ couponId);
    }
    public getCompanyCoupons(): Promise<AxiosResponse<CouponModel[]>>{
        return tokenAxios.get(this.companyUrl+ "companyCoupons");
    }
    public getCompanyCouponsByCategory(category:string): Promise<AxiosResponse<CouponModel[]>>{
        return tokenAxios.get(this.companyUrl+ "couponsByCategory?couponsByCategory="+category);
    }
    public getCompanyCouponsByMaxPrice(maxPrice:number): Promise<AxiosResponse<CouponModel[]>>{
        return tokenAxios.get(this.companyUrl+ "couponsByMaxPrice?couponsByMaxPrice="+maxPrice);
    }
    public getCompanyDetails(): Promise<AxiosResponse<CompanyModel>>{
        return tokenAxios.get(this.companyUrl+ "details");
    }

}

const companyService = new CompanyService();
export default companyService;